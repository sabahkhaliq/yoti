'use strict';

module.exports.yoti = require('./yoti');
