'use strict';

const init = require('./init');

module.exports.initializeProtoBufObjects = () => init.getInstance();
