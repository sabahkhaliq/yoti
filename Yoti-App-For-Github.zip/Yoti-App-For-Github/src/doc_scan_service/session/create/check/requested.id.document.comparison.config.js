'use strict';

/**
 * The configuration applied when creating a RequestedIdDocumentComparisonCheck
 *
 * @class RequestedIdDocumentComparisonConfig
 */
class RequestedIdDocumentComparisonConfig {
  /**
   * @returns {Object} data for JSON.stringify()
   */
  // eslint-disable-next-line class-methods-use-this
  toJSON() {
    return {};
  }
}

module.exports = RequestedIdDocumentComparisonConfig;
