'use strict';

/**
 * The configuration applied when creating a RequestedThirdPartyIdentityCheck
 *
 * @class RequestedThirdPartyIdentityConfig
 */
class RequestedThirdPartyIdentityConfig {
  /**
   * @returns {Object} data for JSON.stringify()
   */
  // eslint-disable-next-line class-methods-use-this
  toJSON() {
    return {};
  }
}

module.exports = RequestedThirdPartyIdentityConfig;
