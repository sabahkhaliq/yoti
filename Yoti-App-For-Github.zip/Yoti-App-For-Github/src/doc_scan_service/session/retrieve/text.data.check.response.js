'use strict';

const CheckResponse = require('./check.response');

class TextDataCheckResponse extends CheckResponse {
}

module.exports = TextDataCheckResponse;
