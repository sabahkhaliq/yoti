'use strict';

const CheckResponse = require('./check.response');

class FaceMatchCheckResponse extends CheckResponse {
}

module.exports = FaceMatchCheckResponse;
