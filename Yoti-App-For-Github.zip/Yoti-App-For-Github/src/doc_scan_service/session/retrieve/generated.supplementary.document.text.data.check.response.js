'use strict';

const GeneratedCheckResponse = require('./generated.check.response');

class GeneratedSupplementaryDocumentTextDataCheckResponse extends GeneratedCheckResponse {
}

module.exports = GeneratedSupplementaryDocumentTextDataCheckResponse;
