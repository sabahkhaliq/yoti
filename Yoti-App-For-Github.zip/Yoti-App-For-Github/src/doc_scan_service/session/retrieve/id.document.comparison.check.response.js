'use strict';

const CheckResponse = require('./check.response');

class IdDocumentComparisonCheckResponse extends CheckResponse {
}

module.exports = IdDocumentComparisonCheckResponse;
