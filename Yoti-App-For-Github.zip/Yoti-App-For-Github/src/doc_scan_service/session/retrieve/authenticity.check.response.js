'use strict';

const CheckResponse = require('./check.response');

class AuthenticityCheckResponse extends CheckResponse {
}

module.exports = AuthenticityCheckResponse;
