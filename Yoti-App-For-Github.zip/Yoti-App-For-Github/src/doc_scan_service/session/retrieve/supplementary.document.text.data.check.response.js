'use strict';

const CheckResponse = require('./check.response');

class SupplementaryDocumentTextDataCheckResponse extends CheckResponse {
}

module.exports = SupplementaryDocumentTextDataCheckResponse;
