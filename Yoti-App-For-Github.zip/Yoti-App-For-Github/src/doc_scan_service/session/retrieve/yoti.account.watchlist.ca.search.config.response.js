'user strict';

const WatchlistAdvancedCaSearchConfigResponse = require('./watchlist.advanced.ca.search.config.response');

class YotiAccountWatchlistCaSearchConfigResponse extends WatchlistAdvancedCaSearchConfigResponse {

}

module.exports = YotiAccountWatchlistCaSearchConfigResponse;
