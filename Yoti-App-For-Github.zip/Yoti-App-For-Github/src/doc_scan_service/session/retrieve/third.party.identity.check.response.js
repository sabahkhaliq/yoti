'use strict';

const ProfileCheckResponse = require('./profile.check.response');

class ThirdPartyIdentityCheckResponse extends ProfileCheckResponse {
}

module.exports = ThirdPartyIdentityCheckResponse;
