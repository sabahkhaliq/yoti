'use strict';

const CheckResponse = require('./check.response');

class LivenessCheckResponse extends CheckResponse {
}

module.exports = LivenessCheckResponse;
