'use strict';

const GeneratedCheckResponse = require('./generated.check.response');

class GeneratedTextDataCheckResponse extends GeneratedCheckResponse {
}

module.exports = GeneratedTextDataCheckResponse;
