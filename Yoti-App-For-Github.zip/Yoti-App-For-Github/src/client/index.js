'use strict';

const YotiClient = require('./yoti.client');
const DocScanClient = require('./doc.scan.client');

module.exports = {
  YotiClient,
  DocScanClient,
};
