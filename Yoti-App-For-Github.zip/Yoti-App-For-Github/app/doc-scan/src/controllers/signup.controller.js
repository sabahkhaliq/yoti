module.exports = async (req, res) => {
  res.render('pages/signup');
};
